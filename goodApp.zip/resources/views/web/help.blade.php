<!-- help.blade.php -->
@extends('layouts.welc')

@section('title') Help &amp; FAQs @endsection
@section('content')
    <div class="container">
    	<div class="col-md-12">
    		
    	</div>
    </div>
@endsection