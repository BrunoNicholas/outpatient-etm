<!-- terms.blade.php -->
@extends('layouts.welc')

@section('title') Terms And Conditions @endsection
@section('content')
    <div class="container">
    	<div class="row">
    		<div class="panel panel-primary">
    			<div class="panel-heading">
    				Company Terms And Conditions
    			</div>
    			<div class="panel-body">
    				
    			</div>
    		</div>
    	</div>
    </div>
@endsection