<?php $__env->startSection('title'); ?> <?php echo e(Auth::user()->name); ?> - Home <?php $__env->stopSection(); ?>
<?php $__env->startSection('location'); ?>
    <h1>Welcome to your Dashboard</h1>
    <ol class="breadcrumb">
        <li class="active">
            <a href="#">
                <i class="livicon" data-name="home" data-size="14" data-color="#333" data-hovercolor="#333"></i> Home
            </a>
        </li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if (\Entrust::hasRole(['super-admin','admin','human_resource','hr_admin'])) : ?>
        <?php echo $__env->make('notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; // Entrust::hasRole ?>
    <div class="number hidden" id="myTargetElement1"></div>
    <h4 class="hidden" id="myTargetElement1.1"></h4>
    <h4 class="hidden" id="myTargetElement1.2"></h4>
    <div class="number hidden" id="myTargetElement2"></div>
    <h4 class="hidden" id="myTargetElement2.1"></h4>
    <h4 class="hidden" id="myTargetElement2.2"></h4>
    <div class="number hidden" id="myTargetElement3"></div>
    <h4 class="hidden" id="myTargetElement3.1"></h4>
    <h4 class="hidden" id="myTargetElement3.2"></h4>
    <div class="number hidden" id="myTargetElement4"></div>
    <h4 class="hidden" id="myTargetElement4.1"></h4>
    <h4 class="hidden" id="myTargetElement4.2"></h4>
    <div class="row ">
        <div class="col-md-8 col-sm-6">
            <div class="panel panel-border">
                <div class="panel-heading">
                    <h3 class="panel-title visitor">
                        <i class="livicon" data-name="map" data-size="20" data-loop="true" data-c="#F89A14" data-hc="#F89A14"></i>
                        Client Tracking Map | 
                        <small> Find the location of all the registered clients</small>
                        <div class="btn-group pull-right">
                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                <i class="livicon" data-name="settings" data-size="16" data-loop="true" data-c="#515763" data-hc="#515763"></i>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a class="panel-collapse collapses" href="#">
                                        <i class="glyphicon glyphicon-chevron-up clickable"></i>
                                        <span>Collapse</span>
                                    </a>
                                </li>
                                <!-- <li>
                                    <a class="panel-refresh" href="#">
                                        <i class="fa fa-refresh"></i>
                                        <span>Refresh</span>
                                    </a>
                                </li> -->
                                <li>
                                    <a class="panel-config" href="#panel-config" data-toggle="modal">
                                        <i class="fa fa-wrench"></i>
                                        <span>Configurations</span>
                                    </a>
                                </li>
                                <!-- <li>
                                    <a class="panel-expand" href="#">
                                        <i class="fa fa-expand"></i>
                                        <span>Fullscreen</span>
                                    </a>
                                </li> -->
                            </ul>
                        </div>
                    </h3>
                </div>
                <div class="panel-body nopadmar">
                    <div id="world-map-markers" style="width:100%; height:300px;"></div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class="panel panel-danger">
                <div class="panel-heading border-light">
                    <h4 class="panel-title">
                        <i class="livicon" data-name="mail" data-size="18" data-color="white" data-hc="white" data-l="true"></i> Send Message
                    </h4>
                </div>
                <div class="panel-body no-padding">
                    <div class="compose row">
                        <form action="<?php echo e(route('chats.store')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>


                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="alert alert-danger"><?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <input type="hidden" name="sender_id" value="<?php echo e(Auth::user()->id); ?>">

                            <input type="hidden" name="sen_email" value="<?php echo e(Auth::user()->email); ?>">

                            <input type="hidden" name="sen_name" value="<?php echo e(Auth::user()->name); ?>">

                            <label class="col-md-3 hidden-xs">To:</label>
                            <select name="receiver_id" class="col-md-9 col-xs-9" tabindex="1" style="padding: 5px; margin-bottom: 3px; border-radius: 5px;">
                                <?php $__currentLoopData = \App\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option  value="<?php echo e($user->id); ?>"><?php echo e($user->email); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="hidden" name="sending_profile" value="<?php echo e(Auth::user()->role); ?>">
                            <div class="clear"></div>

                            <label class="col-md-3 hidden-xs">Subject:</label>
                            <input type="text" name="topic" class="col-md-9 col-xs-9" tabindex="1" placeholder="Subject" required />

                            <div class="clear"></div>

                            <div class='box-body'>
                                <textarea name="description" class="textarea textarea_home resize_vertical" placeholder="Write message content here" required></textarea>                                
                            </div>

                            <br />
                            <div class="pull-right">
                                <button type="submit" class="btn btn-danger">Send</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>