<?php $__env->startSection('title'); ?> System Role (<?php echo e($role->display_name); ?>) <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('location'); ?>
	<h1>The System Users</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(route('home')); ?>">
                <i class="livicon" data-name="home" data-size="14" data-color="#333" data-hovercolor="#333"></i> Home
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin')); ?>">
                <i class="livicon" data-name="dashboard" data-size="14" data-color="#333" data-hovercolor="#333"></i> Admin Dashboard
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('users.index')); ?>">
                <i class="livicon" data-name="warning" data-size="14" data-color="#333" data-hovercolor="#333"></i> Roles
            </a>
        </li>
        <li class="active">
            <a>
                <i class="livicon" data-name="pencil" data-size="14" data-color="#333" data-hovercolor="#333"></i> Edit Role
            </a>
        </li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php if (\Entrust::hasRole(['super-admin','admin','subscriber'])) : ?>
		<?php echo $__env->make('notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; // Entrust::hasRole ?>

    <div class="row">
        <div class="col-md-9">
            <div class="panel panel-danger" id="hidepanel1">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <i class="livicon" data-name="clock" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i>
                        Update Role <?php echo e($role->id); ?>

                    </h3>
                    <span class="pull-right">
                        <i class="glyphicon glyphicon-chevron-up clickable"></i>
                        <i class="glyphicon glyphicon-remove removepanel clickable"></i>
                    </span>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" action="<?php echo e(route('roles.update', $role->id)); ?>" method="POST" style="max-height: 450px; overflow-y: auto;">

                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PATCH')); ?>


                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="alert alert-danger"><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <fieldset>
                            <!-- Name input-->
                            <div class="form-group">
                                <label class="col-md-3 control-label" for="name">Name</label>
                                <div class="col-md-9">
                                    <input id="name" name="name" type="text" placeholder="Names" value="<?php echo e($role->name); ?>" class="form-control" autofocus required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label" for="name">Display Name</label>
                                <div class="col-md-9">
                                    <input id="name" name="display_name" type="text" placeholder="Names" value="<?php echo e($role->display_name); ?>" class="form-control" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label" for="name">Description</label>
                                <div class="col-md-9">
                                    <textarea id="description" name="description" placeholder="Role Description" class="form-control" autofocus><?php echo e($role->description); ?></textarea>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 control-label"> Permissions <span class="text-danger">*</span></label>
                                <div class="col-md-9" style="max-height: 200px; overflow-y: auto;">
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="checkbox" 
                                        <?php echo e(in_array($perm->id, $permission_role)?"checked":""); ?>

                                        name="permission[]" value="<?php echo e($perm->id); ?>"> <?php echo e($perm->display_name); ?> <br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12 text-right">
                                    <div class="row">
                                        <div class="col-md-3 pull-right">
                                            <button type="submit" class="btn btn-responsive btn-primary btn-sm btn-block">Update Role</button>
                                        </div>
                                        <div class="col-md-3 pull-right">
                                            <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-responsive btn-success btn-sm btn-block">Back</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>