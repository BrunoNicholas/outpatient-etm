<?php $__env->startSection('title'); ?> Edit User <?php echo e($user->id); ?> Details <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/dataTables.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/buttons.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/colReorder.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/dataTables.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/rowReorder.bootstrap.c')); ?>ss">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/buttons.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/scroller.bootstrap.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('location'); ?>
	<h1>The System Users</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(route('home')); ?>">
                <i class="livicon" data-name="home" data-size="14" data-color="#333" data-hovercolor="#333"></i> Home
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin')); ?>">
                <i class="livicon" data-name="dashboard" data-size="14" data-color="#333" data-hovercolor="#333"></i> Admin Dashboard
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('users.index')); ?>">
                <i class="livicon" data-name="users" data-size="14" data-color="#333" data-hovercolor="#333"></i> Users
            </a>
        </li>
        <li class="active">
            <a href="#">
                <i class="livicon" data-name="users-add" data-size="14" data-color="#333" data-hovercolor="#333"></i> Add Users
            </a>
        </li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php if (\Entrust::hasRole(['super-admin','admin','subscriber'])) : ?>
		<?php echo $__env->make('notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; // Entrust::hasRole ?>

    <div class="row">
        <div class="col-md-9">
            <div class="panel panel-warning" id="hidepanel1">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <i class="livicon" data-name="clock" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i>
                        Edit <?php echo e($user->name); ?>'s Details
                    </h3>
                    <span class="pull-right">
                        <i class="glyphicon glyphicon-chevron-up clickable"></i>
                        <i class="glyphicon glyphicon-remove removepanel clickable"></i>
                    </span>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" action="<?php echo e(route('users.update', $user->id)); ?>" method="POST" style="max-height: 350px; overflow-y: auto;">

                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PATCH')); ?>


                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="alert alert-danger"><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <fieldset>
                            <!-- Name input-->
                            <div class="form-group">
                                <label class="col-md-3 control-label" for="name">Name</label>
                                <div class="col-md-9">
                                    <input id="name" name="name" type="text" placeholder="Names" value="<?php echo e($user->name); ?>" class="form-control" autofocus required></div>
                            </div>
                            <!-- Email input-->
                            <div class="form-group">
                                <label class="col-md-3 control-label" for="email">E-mail</label>
                                <div class="col-md-9">
                                    <input id="email" name="email" type="text" value="<?php echo e($user->email); ?>" placeholder="mail@example.com" class="form-control" required></div>
                            </div>
                            <!-- Message body -->
                            <div class="form-group">
                                <label class="col-md-3 control-label" for="message">Age</label>
                                <div class="col-md-9">
                                    <input id="number" name="age" type="text" value="<?php echo e($user->age); ?>" placeholder="54" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label" for="message">Location</label>
                                <div class="col-md-9">
                                    <input id="text" name="location" type="text" value="<?php echo e($user->location); ?>" placeholder="Kampala" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label" for="message">Telephone</label>
                                <div class="col-md-9">
                                    <input id="text" name="telephone" type="text" value="<?php echo e($user->telephone); ?>" placeholder="0782 000000" class="form-control" required>
                                </div>
                            </div>

                            <input type="hidden" name="password" value="<?php echo e(bcrypt('dollar')); ?>">

                            <div class="form-group">
                                <label class="col-md-3 control-label" for="message">Gender</label>
                                <div class="col-md-9">
                                <div class="form-control">
                                    <input type="radio" name="gender" value="Male"<?php if($user->gender == 'Male'): ?> checked="checked"  <?php endif; ?>> Male 
                                    <input type="radio" name="gender" value="Female"<?php if($user->gender == 'Female'): ?> checked="checked"  <?php endif; ?>> Female
                                </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-3 control-label" for="message">Designation (Role)</label>
                                <div class="col-md-9" style="padding: 0px;">
                                    <div class="col-md-12">
                                        <div class="col-md-4">
                                            <input type="text" value="<?php echo e($user->role); ?>" class="form-control">
                                        </div>
                                        <div class="col-md-8">
                                            <select name="role" class="form-control">
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($role->name); ?>"><?php echo e($role->display_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-md-3 control-label" for="message">Account Status</label>
                                <div class="col-md-9" style="padding: 0px;">
                                    <div class="col-md-12">
                                        <div class="col-md-4">
                                            <input type="text" value="<?php echo e($user->status); ?>" class="form-control">
                                        </div>
                                        <div class="col-md-8">
                                            <select name="status" class="form-control">
                                                <option value="Active"> Active </option>
                                                <option value="Not Active"> Not Active </option>
                                                <option value="Frozen"> Frozen </option>
                                                <option value="Pending"> Pending </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Form actions -->
                            <div class="form-group">
                                <div class="col-md-12 text-right">
                                    <button type="submit" class="btn btn-responsive btn-primary btn-sm">Update User Profile</button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>