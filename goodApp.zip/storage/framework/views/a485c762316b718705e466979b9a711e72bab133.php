<?php $__env->startSection('title'); ?> Register <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3  col-md-5 col-md-offset-4 col-lg-4 col-lg-offset-4">
    <div class="panel panel-default">
        <div class="panel-heading text-center">
            <img src="<?php echo e(asset('images/favicon.jpg')); ?>" alt="Logo" style="width: 50px;">
            <h3 class="panel-title text-center">Register | <?php echo e(config('app.name')); ?></h3>
        </div>
        <div class="panel-body">
            <form accept-charset="UTF-8" role="form" method="POST" action="<?php echo e(route('register')); ?>">

                <?php echo e(csrf_field()); ?>


                <fieldset>
                    <div class="form-group input-group">
                        <div class="input-group-addon<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <i class="livicon" data-name="user" data-size="18" data-c="#000" data-hc="#000" data-loop="true"></i>
                        </div>
                        <input class="form-control" placeholder="Full Names" type="text"  name="name" value="<?php echo e(old('name')); ?>" required autofocus/>
                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group input-group">
                        <div class="input-group-addon<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <i class="livicon" data-name="mail" data-size="18" data-c="#000" data-hc="#000" data-loop="true"></i>
                        </div>
                        <input class="form-control" placeholder="E-mail" type="email"  name="email" value="<?php echo e(old('email')); ?>" required/>

                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>                        
                    </div>
                    <div class="form-group input-group">
                        <div class="input-group-addon<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <i class="livicon" data-name="key" data-size="18" data-c="#000" data-hc="#000" data-loop="true"></i>
                        </div>
                        <input class="form-control" placeholder="Password" name="password" type="password" required />

                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group input-group">
                        <div class="input-group-addon">
                            <i class="livicon" data-name="key" data-size="18" data-c="#000" data-hc="#000" data-loop="true"></i>
                        </div>
                        <input class="form-control" placeholder="Confirm Password" type="password"  name="password_confirmation" required />
                    </div>
                <!--
                    <div class="form-group input-group">
                        <div class="input-group-addon<?php echo e($errors->has('age') ? ' has-error' : ''); ?>">
                            <i class="livicon" data-name="user" data-size="18" data-c="#000" data-hc="#000" data-loop="true"></i>
                        </div>
                        <input class="form-control" placeholder="Age" type="number"  name="age" value="<?php echo e(old('age')); ?>" required autofocus/>
                        <?php if($errors->has('age')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('age')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group input-group">
                        <div class="input-group-addon<?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
                            <i class="livicon" data-name="user" data-size="18" data-c="#000" data-hc="#000" data-loop="true"></i>
                        </div>
                        <div class="form-control">
                            <input type="radio" name="gender" value="Male" checked="checked"> Male  
                            <input type="radio" name="gender" value="Female" checked="checked"> Female  
                        </div>                        
                    </div>

                    <input type="hidden" name="role" value="subscriber">

                    <input type="hidden" name="status" value="Pending">
                -->
                    <div class="form-group">
                        <label>
                            <input type="checkbox" value="Remember Me" class="minimal-blue"> I agree to the <a href="">Terms &amp; Conditions</a>
                        </label>
                    </div>
                    <button type="submit" class="btn btn-lg btn-primary btn-block">Register</button>
                </fieldset>
                <hr>
                <fieldset>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-md btn-info btn-block">Login</a>
                </fieldset>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auths', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>