<!-- nlogin.blade.php -->


<?php $__env->startSection('title'); ?> Login <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3  col-md-5 col-md-offset-4 col-lg-4 col-lg-offset-4">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title text-center">Register | <?php echo e(config('app.name')); ?></h3>
        </div>
        <div class="panel-body">
            <form accept-charset="UTF-8" role="form" method="POST" action="<?php echo e(route('register')); ?>">

            	<?php echo e(csrf_field()); ?>


                <fieldset>
                    <div class="form-group input-group">
                        <div class="input-group-addon<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <i class="livicon" data-name="user" data-size="18" data-c="#000" data-hc="#000" data-loop="true"></i>
                        </div>
                        <input class="form-control" placeholder="Full Names" type="text"  name="name" value="<?php echo e(old('name')); ?>" required autofocus/>
                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group input-group">
                        <div class="input-group-addon<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <i class="livicon" data-name="mail" data-size="18" data-c="#000" data-hc="#000" data-loop="true"></i>
                        </div>
                        <input class="form-control" placeholder="E-mail" type="email"  name="email" value="<?php echo e(old('email')); ?>" required/>

                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>                        
                    </div>
                    <div class="form-group input-group">
                        <div class="input-group-addon<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <i class="livicon" data-name="key" data-size="18" data-c="#000" data-hc="#000" data-loop="true"></i>
                        </div>
                        <input class="form-control" placeholder="Password" name="password" type="password" required />

                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group input-group">
                        <div class="input-group-addon">
                            <i class="livicon" data-name="key" data-size="18" data-c="#000" data-hc="#000" data-loop="true"></i>
                        </div>
                        <input class="form-control" placeholder="Confirm Password" type="password"  name="password_confirmation" required />
                    </div>
                    <div class="form-group">
                        <label>
                            <input name="remember" type="checkbox" value="Remember Me" class="minimal-blue"> I agree for terms
                        </label>
                    </div>
                    <button type="submit" class="btn btn-lg btn-primary btn-block">Register</button>
                </fieldset>
                <hr>
                <fieldset>
                	<a href="<?php echo e(route('login')); ?>" class="btn btn-md btn-info btn-block">Remember Password</a>
                </fieldset>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auths', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>