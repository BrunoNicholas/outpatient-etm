<!-- nlogin.blade.php -->


<?php $__env->startSection('title'); ?> Login <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class=" col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-3  col-md-5 col-md-offset-4 col-lg-4 col-lg-offset-4">
    <div class="panel panel-default">
        <div class="panel-heading text-center">
            <img src="<?php echo e(asset('images/favicon.jpg')); ?>" alt="Logo" style="width: 50px;">
            <h3 class="panel-title text-center">Sign In | <?php echo e(config('app.name')); ?></h3>
        </div>
        <div class="panel-body">
            <form accept-charset="UTF-8" role="form" method="POST" action="<?php echo e(route('login')); ?>">

                <?php echo e(csrf_field()); ?>


                <fieldset>
                    <div class="form-group input-group">
                        <div class="input-group-addon<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <i class="livicon" data-name="mail" data-size="18" data-c="#484848" data-hc="#484848" data-loop="true"></i>
                        </div>
                        <input class="form-control" placeholder="E-mail" type="text"  name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group input-group">
                        <div class="input-group-addon<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <i class="livicon" data-name="key" data-size="18" data-c="#484848" data-hc="#484848" data-loop="true"></i>
                        </div>
                        <input class="form-control" type="password"  name="password" required>
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>
                            <input type="checkbox" class="minimal-blue"  name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                        </label>
                    </div>
                    <button type="submit" class="btn btn-lg btn-primary btn-block"> Sign In </button>
                </fieldset>
                <hr>
                <fieldset>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6">
                                <a href="<?php echo e(route('password.request')); ?>" class="btn btn-md btn-warning btn-block">Forgort Password</a>
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(route('register')); ?>" class="btn btn-md btn-info btn-block">Register</a>
                            </div>
                        </div>
                    </div>
                    
                </fieldset>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auths', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>