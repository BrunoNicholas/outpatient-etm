<!-- index.blade.php -->


<?php $__env->startSection('title'); ?> Disease Cases <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/dataTables.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/buttons.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/colReorder.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/dataTables.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/rowReorder.bootstrap.c')); ?>ss">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/buttons.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/scroller.bootstrap.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('location'); ?>
	<h1>The System Users</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(route('home')); ?>">
                <i class="livicon" data-name="home" data-size="14" data-color="#333" data-hovercolor="#333"></i> Home
            </a>
        </li>
        <li class="active">
            <a href="#">
                <i class="livicon" data-name="bug" data-size="14" data-color="#333" data-hovercolor="#333"></i> Disease Records
            </a>
        </li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="row ">
        <div class="col-md-10 col-sm-8">

        </div>
        <div class="col-md-2 col-sm-8">
        	<div class="panel panel-danger filterable">
        		<div class="panel-body text-center">
    				<div class="row">
        				<a href="<?php echo e(route('cases.create')); ?>" class="btn btn-primary">Add New</a>
        				<hr>
        				<a href="<?php echo e(route('home')); ?>" class="btn btn-default">Home</a>
        				<hr>
        				<a href="#" class="btn btn-default">Tracker</a>
        				<hr>
        				<a href="#" class="btn btn-default">Tracker</a>
        			</div>
        		</div>
        	</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/jquery.dataTables.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/jeditable/js/jquery.jeditable.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.bootstrap.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.buttons.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.colReorder.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.responsive.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.rowReorder.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/buttons.colVis.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/buttons.html5.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/buttons.print.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/buttons.bootstrap.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/pdfmake.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/vfs_fonts.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.scroller.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/js/pages/table-advanced.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>