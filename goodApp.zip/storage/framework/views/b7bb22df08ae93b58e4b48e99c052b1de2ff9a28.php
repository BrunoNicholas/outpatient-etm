<!-- auths.blade.php -->
<!DOCTYPE html>
<html>

<head>
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- global level css -->
    <link href="<?php echo e(asset('app/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <!-- end of global level css -->
    <!-- page level css -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/favicon.png')); ?>">
    <link href="<?php echo e(asset('app/css/pages/login2.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('app/vendors/iCheck/css/minimal/blue.css')); ?>" rel="stylesheet" />
    <!-- styles of the page ends-->
</head>

<body>
    <div class="container">
        <div class="row vertical-offset-100">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <!-- global js -->
    <script src="<?php echo e(asset('app/js/app.js')); ?>" type="text/javascript"></script>
    <!-- end of global js -->
    <!-- begining of page level js-->
    <script src="<?php echo e(asset('app/js/TweenLite.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app/vendors/iCheck/js/icheck.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('app/js/pages/login2.js')); ?>" type="text/javascript"></script>
    <!-- end of page level js-->
</body>

</html>
