<!-- index.blade.php -->


<?php $__env->startSection('title'); ?> Employee Leave Records <?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/dataTables.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/buttons.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/colReorder.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/dataTables.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/rowReorder.bootstrap.c')); ?>ss">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/buttons.bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app/vendors/datatables/css/scroller.bootstrap.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('location'); ?>
	<h1>Leave records for all employees of the System</h1>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(route('home')); ?>">
                <i class="livicon" data-name="home" data-size="14" data-color="#333" data-hovercolor="#333"></i> Home
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin')); ?>">
                <i class="livicon" data-name="dashboard" data-size="14" data-color="#333" data-hovercolor="#333"></i> Admin
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('users.index')); ?>">
                <i class="livicon" data-name="users" data-size="14" data-color="#333" data-hovercolor="#333"></i> Users
            </a>
        </li>
        <li class="active">
            <a href="#">
                <i class="livicon" data-name="users-add" data-size="14" data-color="#333" data-hovercolor="#333"></i> Employee Leave Records
            </a>
        </li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/jquery.dataTables.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/jeditable/js/jquery.jeditable.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.bootstrap.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.buttons.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.colReorder.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.responsive.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.rowReorder.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/buttons.colVis.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/buttons.html5.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/buttons.print.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/buttons.bootstrap.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/pdfmake.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/vfs_fonts.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/vendors/datatables/js/dataTables.scroller.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('app/js/pages/table-advanced.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>