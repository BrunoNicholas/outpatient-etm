<!-- terms.blade.php -->


<?php $__env->startSection('title'); ?> Terms And Conditions <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
    	<div class="row">
    		<div class="panel panel-primary">
    			<div class="panel-heading">
    				Company Terms And Conditions
    			</div>
    			<div class="panel-body">
    				
    			</div>
    		</div>
    	</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.welc', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>