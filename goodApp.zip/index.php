<!DOCTYPE html>
<html>
<head>
	<title>OUTPATIENT SOFTWARE | ETM - Pro</title>
	<link href="public/app/css/bootstrap.min.css" rel="stylesheet" />
	<style type="text/css">
		body {
			margin-left: 15%;
			margin-right: 15%;
			margin-top: 250px;
		}
	</style>
</head>
<body>
	<div class="container">
		<div class="col-lg-12">
			<div class="row">
				<div class="col-lg-3">
					
				</div>
				<div class="col-lg-3 text-center">
					<a href="/etm_pro/public">
						<button class="btn btn-primary btn-block">Continue to Site!</button>
					</a>
				</div>
				<div class="col-lg-3">
					
				</div>
			</div>
		</div>
	</div>
</body>
</html>