# Outpatient-ETM
This is a medical software for field medics who interract with their patients and monitor their dosage and treatment to any subscribed medical facility
